import { config } from 'dotenv';
config();

import '@/ai/flows/translate-property-description.ts';