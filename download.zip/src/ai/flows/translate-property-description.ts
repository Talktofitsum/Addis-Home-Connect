'use server';

/**
 * @fileOverview This file defines a Genkit flow to translate property descriptions from English to Amharic and Oromifa.
 *
 * - translatePropertyDescription - A function that translates the property description.
 * - TranslatePropertyDescriptionInput - The input type for the translatePropertyDescription function.
 * - TranslatePropertyDescriptionOutput - The return type for the translatePropertyDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const TranslatePropertyDescriptionInputSchema = z.object({
  descriptionEn: z.string().describe('The English description of the property.'),
});
export type TranslatePropertyDescriptionInput = z.infer<typeof TranslatePropertyDescriptionInputSchema>;

const TranslatePropertyDescriptionOutputSchema = z.object({
  descriptionAm: z.string().describe('The Amharic translation of the property description.'),
  descriptionOr: z.string().describe('The Oromifa translation of the property description.'),
});
export type TranslatePropertyDescriptionOutput = z.infer<typeof TranslatePropertyDescriptionOutputSchema>;

export async function translatePropertyDescription(input: TranslatePropertyDescriptionInput): Promise<TranslatePropertyDescriptionOutput> {
  return translatePropertyDescriptionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'translatePropertyDescriptionPrompt',
  input: {schema: TranslatePropertyDescriptionInputSchema},
  output: {schema: TranslatePropertyDescriptionOutputSchema},
  prompt: `You are a translation expert specializing in real estate descriptions for the Addis Ababa market.  You will translate the provided English description into both Amharic and Oromifa.

English Description: {{{descriptionEn}}}

Respond with a JSON object with the translations in the following format:
{
  "descriptionAm": "[Amharic Translation]",
  "descriptionOr": "[Oromifa Translation]"
}
`,
});

const translatePropertyDescriptionFlow = ai.defineFlow(
  {
    name: 'translatePropertyDescriptionFlow',
    inputSchema: TranslatePropertyDescriptionInputSchema,
    outputSchema: TranslatePropertyDescriptionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
