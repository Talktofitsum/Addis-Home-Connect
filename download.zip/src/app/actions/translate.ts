"use server";

import { translatePropertyDescription } from "@/ai/flows/translate-property-description";
import { z } from "zod";

const schema = z.object({
    descriptionEn: z.string().min(1, "Description is required"),
});

export async function translateDescriptionAction(
  prevState: any,
  formData: FormData
) {
  const validatedFields = schema.safeParse({
    descriptionEn: formData.get("descriptionEn"),
  });

  if (!validatedFields.success) {
    return {
      error: "Invalid input. Please provide a description to translate.",
    };
  }
  
  try {
    const result = await translatePropertyDescription({
      descriptionEn: validatedFields.data.descriptionEn,
    });
    return {
      descriptionAm: result.descriptionAm,
      descriptionOr: result.descriptionOr,
      error: null,
    };
  } catch (error) {
    console.error("Translation failed:", error);
    return {
      error: "AI translation failed. Please try again later.",
    };
  }
}
