'use client';

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { useFormState } from "react-dom";

import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { translateDescriptionAction } from "@/app/actions/translate";
import { Wand2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

const propertyFormSchema = z.object({
  title: z.string().min(10, { message: "Title must be at least 10 characters." }),
  descriptionEn: z.string().min(50, { message: "English description must be at least 50 characters." }),
  descriptionAm: z.string().optional(),
  descriptionOr: z.string().optional(),
  town: z.string().min(1, { message: "Town is required." }),
  subcity: z.string().min(1, { message: "Subcity is required." }),
  site: z.string().min(1, { message: "Site is required." }),
  lat: z.coerce.number(),
  lng: z.coerce.number(),
  area: z.coerce.number().min(1, { message: "Area must be positive." }),
  bedrooms: z.coerce.number().min(0),
  bathrooms: z.coerce.number().min(1),
  blockNo: z.string().min(1, { message: "Block number is required." }),
  floorNo: z.coerce.number(),
  houseNo: z.string().min(1, { message: "House number is required." }),
  price: z.coerce.number().min(1, { message: "Price must be positive." }),
})

type PropertyFormValues = z.infer<typeof propertyFormSchema>

const initialState = {
  descriptionAm: "",
  descriptionOr: "",
  error: null,
};

export default function NewPropertyPage() {
  const [state, formAction] = useFormState(translateDescriptionAction, initialState);
  const { toast } = useToast();

  const form = useForm<PropertyFormValues>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: {
      title: "",
      descriptionEn: "",
      descriptionAm: "",
      descriptionOr: "",
      town: "Addis Ababa",
      subcity: "",
      site: "",
      lat: 9.0054,
      lng: 38.7636,
      area: 0,
      bedrooms: 1,
      bathrooms: 1,
      blockNo: "",
      floorNo: 0,
      houseNo: "",
      price: 0
    },
  });

  function onSubmit(data: PropertyFormValues) {
    console.log(data);
    toast({
        title: "Property Submitted",
        description: "Your property has been submitted for review.",
    });
  }

  useEffect(() => {
    if (state.descriptionAm) {
        form.setValue("descriptionAm", state.descriptionAm);
    }
    if (state.descriptionOr) {
        form.setValue("descriptionOr", state.descriptionOr);
    }
    if (state.error) {
        toast({
            variant: "destructive",
            title: "Translation Failed",
            description: state.error,
        });
    }
  }, [state, form, toast]);

  return (
    <div>
      <h1 className="text-3xl font-bold font-headline mb-6">Add New Property</h1>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle>Property Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <FormField control={form.control} name="title" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Property Title</FormLabel>
                            <FormControl><Input placeholder="e.g., Cozy 2-Bedroom Condo in Bole" {...field} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Description</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <FormField control={form.control} name="descriptionEn" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Description (English)</FormLabel>
                            <FormControl><Textarea placeholder="Describe the property in detail..." {...field} rows={6} /></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                    
                    <form action={formAction}>
                        <input type="hidden" name="descriptionEn" value={form.watch("descriptionEn")} />
                        <Button type="submit" variant="outline">
                            <Wand2 className="mr-2 h-4 w-4" />
                            Generate Amharic & Oromifa Translations with AI
                        </Button>
                    </form>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField control={form.control} name="descriptionAm" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Description (Amharic)</FormLabel>
                                <FormControl><Textarea placeholder="የአማርኛ መግለጫ..." {...field} rows={6} className="font-belleza" /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="descriptionOr" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Description (Oromifa)</FormLabel>
                                <FormControl><Textarea placeholder="Ibsa Afaan Oromoo..." {...field} rows={6} className="font-belleza" /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Location & Specs</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                   <div className="grid md:grid-cols-3 gap-4">
                        <FormField control={form.control} name="subcity" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Subcity</FormLabel>
                                <FormControl><Input placeholder="Bole" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="site" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Site</FormLabel>
                                <FormControl><Input placeholder="Bole Michael" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="price" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Price (ETB/month)</FormLabel>
                                <FormControl><Input type="number" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                     <div className="grid md:grid-cols-2 gap-4">
                        <FormField control={form.control} name="lat" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Latitude</FormLabel>
                                <FormControl><Input type="number" step="any" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                         <FormField control={form.control} name="lng" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Longitude</FormLabel>
                                <FormControl><Input type="number" step="any" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                    <div className="grid md:grid-cols-3 gap-4">
                       <FormField control={form.control} name="bedrooms" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Bedrooms</FormLabel>
                                <FormControl><Input type="number" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="bathrooms" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Bathrooms</FormLabel>
                                <FormControl><Input type="number" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                         <FormField control={form.control} name="area" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Area (m²)</FormLabel>
                                <FormControl><Input type="number" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                     <div className="grid md:grid-cols-3 gap-4">
                       <FormField control={form.control} name="blockNo" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Block No.</FormLabel>
                                <FormControl><Input {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="floorNo" render={({ field }) => (
                            <FormItem>
                                <FormLabel>Floor No.</FormLabel>
                                <FormControl><Input type="number" {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                         <FormField control={form.control} name="houseNo" render={({ field }) => (
                            <FormItem>
                                <FormLabel>House No.</FormLabel>
                                <FormControl><Input {...field} /></FormControl>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                </CardContent>
            </Card>

            <Button type="submit" size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">Submit Property</Button>
        </form>
      </Form>
    </div>
  );
}
