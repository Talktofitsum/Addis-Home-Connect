'use client';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useLanguage } from "@/contexts/language-context";
import { cn } from "@/lib/utils";

export default function SubscriptionPage() {
    const { t, language } = useLanguage();

    const plans = [
        {
            title: t('basic_plan'),
            price: t('basic_plan_price'),
            features: t('basic_plan_features'),
            isFeatured: false,
        },
        {
            title: t('premium_plan'),
            price: t('premium_plan_price'),
            features: t('premium_plan_features'),
            isFeatured: true,
        },
        {
            title: t('broker_plan'),
            price: t('broker_plan_price'),
            features: t('broker_plan_features'),
            isFeatured: false,
        },
    ];

    return (
        <div className="flex flex-col items-center">
            <div className="text-center mb-12">
                <h1 className={cn("text-4xl font-bold font-headline", language !== 'en' && 'font-belleza text-5xl')}>{t('subscription_title')}</h1>
                <p className={cn("text-lg text-muted-foreground mt-2", language !== 'en' && 'font-belleza text-xl')}>{t('subscription_subtitle')}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl">
                {plans.map((plan, index) => (
                    <Card key={index} className={cn("flex flex-col", plan.isFeatured && "border-primary border-2 shadow-lg")}>
                        <CardHeader>
                            <CardTitle className={cn("font-headline", language !== 'en' && 'font-belleza text-3xl')}>{plan.title}</CardTitle>
                            <CardDescription className="text-2xl font-bold text-primary pt-2">{plan.price}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <ul className="space-y-3">
                                {Array.isArray(plan.features) && plan.features.map((feature, i) => (
                                    <li key={i} className="flex items-start">
                                        <Check className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-1" />
                                        <span className={cn("text-muted-foreground", language !== 'en' && 'font-belleza text-base')}>{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                        <CardFooter>
                            <Button className={cn("w-full", plan.isFeatured ? "bg-accent text-accent-foreground hover:bg-accent/90" : "bg-primary text-primary-foreground")}>
                                {t('choose_plan')}
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    );
}
