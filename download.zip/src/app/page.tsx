import Image from 'next/image';
import {
  Home,
  MapPin,
  Search,
  BedDouble,
  Bath,
  Maximize,
  SlidersHorizontal,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { properties } from '@/lib/data';
import PropertyCard from '@/components/property-card';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import PropertyFilters from '@/components/property-filters';
import placeholderImages from '@/lib/placeholder-images.json';

export default function HomePage() {
  const heroImage = placeholderImages.placeholderImages.find(p => p.id === "hero-1");

  return (
    <div className="flex flex-col">
      <section className="relative w-full h-[400px] md:h-[500px]">
        {heroImage && (
          <Image
            src={heroImage.imageUrl}
            alt="Hero background image of Addis Ababa skyline"
            fill
            className="object-cover"
            priority
            data-ai-hint={heroImage.imageHint}
          />
        )}
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative container mx-auto px-4 h-full flex flex-col items-center justify-center text-center text-white">
          <h1 className="text-4xl md:text-6xl font-headline font-bold mb-4 drop-shadow-lg">
            Find Your Next Home in Addis
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl drop-shadow-md">
            The #1 marketplace for condominium rentals in Addis Ababa.
          </p>
          <Card className="w-full max-w-4xl p-4 bg-background/80 backdrop-blur-sm">
            <div className="flex flex-col md:flex-row gap-2 items-center">
              <div className="relative flex-grow w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Enter a subcity, site, or keyword..."
                  className="pl-10 w-full"
                />
              </div>
              <Button size="lg" className="w-full md:w-auto bg-accent text-accent-foreground hover:bg-accent/90">
                <Search className="mr-2 h-5 w-5" />
                Search
              </Button>
               <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="lg" className="w-full md:w-auto">
                    <SlidersHorizontal className="mr-2 h-5 w-5" />
                    Filters
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-[350px] sm:w-[450px]">
                  <SheetHeader>
                    <SheetTitle>Advanced Filters</SheetTitle>
                    <SheetDescription>
                      Refine your search to find the perfect home.
                    </SheetDescription>
                  </SheetHeader>
                  <div className="py-4">
                    <PropertyFilters />
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </Card>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-headline font-semibold">
              Featured Properties
            </h2>
            <Button variant="link" className="text-primary">
              View All
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {properties.slice(0, 8).map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
