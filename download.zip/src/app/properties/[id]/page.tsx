import Image from 'next/image';
import dynamic from 'next/dynamic';
import { notFound } from 'next/navigation';
import { properties, users } from '@/lib/data';
import placeholderImages from '@/lib/placeholder-images.json';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import {
  BedDouble,
  Bath,
  Maximize,
  MapPin,
  CalendarDays,
  User,
  Phone,
  MessageSquare,
} from 'lucide-react';

const MapView = dynamic(() => import('@/components/map-view'), {
  ssr: false,
  loading: () => <div className="h-full w-full bg-muted animate-pulse" />,
});

export default function PropertyDetailPage({ params }: { params: { id: string } }) {
  const property = properties.find((p) => p.id === params.id);

  if (!property) {
    notFound();
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 0,
    }).format(price);
  };
  
  const poster = property.poster;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Image Carousel */}
          <Carousel className="w-full mb-6 rounded-lg overflow-hidden">
            <CarouselContent>
              {property.photos.map((photoId, index) => {
                const image = placeholderImages.placeholderImages.find(p => p.id === photoId);
                return (
                  <CarouselItem key={index}>
                    <div className="relative h-96">
                      {image && (
                        <Image
                          src={image.imageUrl}
                          alt={`${property.title} - photo ${index + 1}`}
                          fill
                          className="object-cover"
                          data-ai-hint={image.imageHint}
                        />
                      )}
                    </div>
                  </CarouselItem>
                );
              })}
            </CarouselContent>
            <CarouselPrevious className="ml-16" />
            <CarouselNext className="mr-16" />
          </Carousel>

          {/* Main Details */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                  <div>
                      <h1 className="text-3xl font-bold font-headline mb-2">{property.title}</h1>
                      <div className="flex items-center text-muted-foreground">
                          <MapPin className="h-5 w-5 mr-2" />
                          <span>{`${property.location.site}, ${property.location.subcity}`}</span>
                      </div>
                  </div>
                  <Badge variant={property.poster.role === 'broker' ? 'destructive' : 'secondary'} className="text-sm">
                      {property.poster.role === 'broker' ? `Broker (+${property.commissionPercent}%)` : 'By Owner'}
                  </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-x-6 gap-y-3 text-lg my-4">
                  <div className="flex items-center gap-2">
                      <BedDouble className="h-6 w-6 text-primary" />
                      <span>{property.bedrooms} Bedrooms</span>
                  </div>
                  <div className="flex items-center gap-2">
                      <Bath className="h-6 w-6 text-primary" />
                      <span>{property.bathrooms} Bathrooms</span>
                  </div>
                  <div className="flex items-center gap-2">
                      <Maximize className="h-6 w-6 text-primary" />
                      <span>{property.areaM2} m²</span>
                  </div>
                  <div className="flex items-center gap-2">
                      <CalendarDays className="h-6 w-6 text-primary" />
                      <span>Available from {new Date(property.availableFrom).toLocaleDateString()}</span>
                  </div>
              </div>

              <Separator className="my-6" />

              <h2 className="text-2xl font-headline font-semibold mb-4">Description</h2>
              <p className="text-muted-foreground leading-relaxed">
                  {property.description.en}
              </p>
              
              <Separator className="my-6" />

              <h2 className="text-2xl font-headline font-semibold mb-4">Location</h2>
              <div className="h-80 w-full rounded-lg overflow-hidden">
                <MapView
                  center={[property.location.gps.lat, property.location.gps.lng]}
                  markerPosition={[property.location.gps.lat, property.location.gps.lng]}
                  markerPopup={property.title}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
            <Card className="sticky top-24">
                <CardContent className="p-6">
                    <div className="mb-4">
                        <span className="text-3xl font-bold text-primary">{formatPrice(property.price)}</span>
                        <span className="text-muted-foreground">/month</span>
                    </div>
                    {property.poster.role === 'broker' && (
                        <p className="text-sm text-destructive mb-4">A commission of {property.commissionPercent}% applies.</p>
                    )}
                    <Button size="lg" className="w-full bg-accent text-accent-foreground hover:bg-accent/90">Request to Book</Button>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Posted by</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex items-center space-x-4">
                        <Avatar className="h-16 w-16">
                            <AvatarImage src={poster.avatarUrl} alt={poster.name} />
                            <AvatarFallback>{poster.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            <p className="font-semibold text-lg">{poster.name}</p>
                            <p className="text-sm text-muted-foreground capitalize">{poster.role}</p>
                        </div>
                    </div>
                     <div className="mt-4 space-y-2">
                        <Button variant="outline" className="w-full justify-start"><Phone className="mr-2 h-4 w-4"/> Show Phone Number</Button>
                        <Button variant="outline" className="w-full justify-start"><MessageSquare className="mr-2 h-4 w-4"/> Send Message</Button>
                    </div>
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
}
