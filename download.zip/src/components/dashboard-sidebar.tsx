'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Home,
  PlusCircle,
  MessageSquare,
  Heart,
  CreditCard,
  User,
  Settings,
} from 'lucide-react';

const ownerLinks = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/dashboard/properties', label: 'My Properties', icon: Home },
  { href: '/dashboard/properties/new', label: 'Add Property', icon: PlusCircle },
  { href: '/dashboard/messages', label: 'Messages', icon: MessageSquare },
  { href: '/dashboard/subscription', label: 'Subscription', icon: CreditCard },
];

const renterLinks = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/dashboard/wishlist', label: 'My Wishlist', icon: Heart },
  { href: '/dashboard/messages', label: 'My Messages', icon: MessageSquare },
];

const commonLinks = [
    { href: '/dashboard/profile', label: 'Profile', icon: User },
    { href: '/dashboard/settings', label: 'Settings', icon: Settings },
]

export function DashboardSidebar() {
  const pathname = usePathname();
  // TODO: Replace with actual user role from auth
  const userRole: 'owner' | 'renter' | 'broker' = 'owner';

  const links = userRole === 'renter' ? renterLinks : ownerLinks;

  return (
    <nav className="flex flex-col space-y-1 sticky top-24">
      {links.map((link) => (
        <Button
          key={link.href}
          asChild
          variant={pathname === link.href ? 'default' : 'ghost'}
          className={cn(
            'w-full justify-start',
            pathname === link.href && 'bg-primary text-primary-foreground hover:bg-primary/90'
          )}
        >
          <Link href={link.href}>
            <link.icon className="mr-2 h-4 w-4" />
            {link.label}
          </Link>
        </Button>
      ))}
      <hr className="my-2" />
      {commonLinks.map((link) => (
         <Button
          key={link.href}
          asChild
          variant={pathname === link.href ? 'default' : 'ghost'}
          className={cn(
            'w-full justify-start',
            pathname === link.href && 'bg-primary text-primary-foreground hover:bg-primary/90'
          )}
        >
          <Link href={link.href}>
            <link.icon className="mr-2 h-4 w-4" />
            {link.label}
          </Link>
        </Button>
      ))}
    </nav>
  );
}
