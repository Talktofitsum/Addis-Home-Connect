import Link from 'next/link';
import { Building2, Twitter, Facebook, Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-headline font-semibold mb-4">Addis Home Connect</h3>
            <p className="text-sm text-muted-foreground">
              Your partner in finding the perfect condominium in Addis Ababa.
            </p>
          </div>
          <div>
            <h3 className="font-headline font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/#" className="hover:text-primary">Search Properties</Link></li>
              <li><Link href="/dashboard" className="hover:text-primary">My Dashboard</Link></li>
              <li><Link href="/#" className="hover:text-primary">About Us</Link></li>
              <li><Link href="/#" className="hover:text-primary">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-headline font-semibold mb-4">For Owners</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/dashboard/properties/new" className="hover:text-primary">Post a Property</Link></li>
              <li><Link href="/dashboard/subscription" className="hover:text-primary">Pricing</Link></li>
              <li><Link href="/#" className="hover:text-primary">Owner FAQ</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-headline font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <Link href="#" aria-label="Twitter">
                <Twitter className="h-6 w-6 text-muted-foreground hover:text-primary" />
              </Link>
              <Link href="#" aria-label="Facebook">
                <Facebook className="h-6 w-6 text-muted-foreground hover:text-primary" />
              </Link>
              <Link href="#" aria-label="Instagram">
                <Instagram className="h-6 w-6 text-muted-foreground hover:text-primary" />
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-border pt-4 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Addis Home Connect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
