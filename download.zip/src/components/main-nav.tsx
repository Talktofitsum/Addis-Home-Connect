'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/contexts/language-context';

export function MainNav({ isMobile = false }: { isMobile?: boolean }) {
  const pathname = usePathname();
  const { t } = useLanguage();

  const navLinks = [
    { href: '/', label: t('nav_search') },
    { href: '/dashboard/properties/new', label: t('nav_post_property') },
    { href: '/dashboard/subscription', label: t('nav_pricing') },
    { href: '/#about', label: t('nav_about') },
  ];

  const linkClass = (href: string) =>
    cn(
      'transition-colors hover:text-primary',
      pathname === href
        ? 'text-foreground font-medium'
        : 'text-muted-foreground',
      isMobile ? 'text-lg py-2 block' : 'text-sm'
    );

  return (
    <nav className={cn("items-center space-x-4 lg:space-x-6", isMobile ? 'flex flex-col space-x-0 space-y-2 items-start' : 'flex')}>
      {navLinks.map((link) => (
        <Link key={link.href} href={link.href} className={linkClass(link.href)}>
          {link.label}
        </Link>
      ))}
    </nav>
  );
}
