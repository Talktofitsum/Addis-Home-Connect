import Image from 'next/image';
import Link from 'next/link';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BedDouble, Bath, Maximize, MapPin, Heart } from 'lucide-react';
import type { Property } from '@/lib/types';
import placeholderImages from '@/lib/placeholder-images.json';

interface PropertyCardProps {
  property: Property;
}

export default function PropertyCard({ property }: PropertyCardProps) {
  const firstImageId = property.photos[0];
  const image = placeholderImages.placeholderImages.find(p => p.id === firstImageId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'ETB',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <Card className="flex flex-col overflow-hidden h-full shadow-md hover:shadow-xl transition-shadow duration-300">
      <CardHeader className="p-0 relative">
        <Link href={`/properties/${property.id}`} className="block">
          {image && (
            <Image
              src={image.imageUrl}
              alt={property.title}
              width={600}
              height={400}
              className="w-full h-48 object-cover"
              data-ai-hint={image.imageHint}
            />
          )}
        </Link>
        <Badge
          className="absolute top-2 left-2"
          variant={property.poster.role === 'broker' ? 'destructive' : 'secondary'}
        >
          {property.poster.role === 'broker' ? `Broker (+${property.commissionPercent}%)` : 'By Owner'}
        </Badge>
         <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-white/70 hover:bg-white rounded-full h-8 w-8">
            <Heart className="h-4 w-4 text-primary" />
            <span className="sr-only">Add to wishlist</span>
        </Button>
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <Link href={`/properties/${property.id}`} className="block">
          <CardTitle className="text-lg font-headline leading-tight mb-2 h-14 hover:text-primary transition-colors">
            {property.title}
          </CardTitle>
        </Link>
        <div className="flex items-center text-sm text-muted-foreground mb-4">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{`${property.location.site}, ${property.location.subcity}`}</span>
        </div>

        <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <BedDouble className="h-4 w-4" />
            <span>{property.bedrooms} Beds</span>
          </div>
          <div className="flex items-center gap-1">
            <Bath className="h-4 w-4" />
            <span>{property.bathrooms} Baths</span>
          </div>
          <div className="flex items-center gap-1">
            <Maximize className="h-4 w-4" />
            <span>{property.areaM2} m²</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 flex justify-between items-center bg-secondary/50">
        <div className="text-xl font-bold text-primary">
          {formatPrice(property.price)}
          <span className="text-sm font-normal text-muted-foreground">/month</span>
        </div>
        <Button asChild size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
          <Link href={`/properties/${property.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
