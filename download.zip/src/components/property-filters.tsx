'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useState } from 'react';

const subcities = [
  'Arada',
  'Bole',
  'Gullele',
  'Kirkos',
  'Kolfe Keranio',
  'Lideta',
  'Nifas Silk-Lafto',
  'Yeka',
  'Lemi Kura',
  'Akaky Kaliti',
];

export default function PropertyFilters() {
  const [priceRange, setPriceRange] = useState([5000, 50000]);

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="price-range">Price Range (ETB)</Label>
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>{priceRange[0].toLocaleString()}</span>
          <span>{priceRange[1].toLocaleString()}+</span>
        </div>
        <Slider
          id="price-range"
          min={1000}
          max={100000}
          step={1000}
          value={priceRange}
          onValueChange={setPriceRange}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="bedrooms">Bedrooms</Label>
        <Select>
          <SelectTrigger id="bedrooms">
            <SelectValue placeholder="Any" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any</SelectItem>
            <SelectItem value="1">1</SelectItem>
            <SelectItem value="2">2</SelectItem>
            <SelectItem value="3">3</SelectItem>
            <SelectItem value="4">4+</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="subcity">Subcity</Label>
        <Select>
          <SelectTrigger id="subcity">
            <SelectValue placeholder="Select a subcity" />
          </SelectTrigger>
          <SelectContent>
            {subcities.map((city) => (
              <SelectItem key={city} value={city}>
                {city}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="site">Site/Area</Label>
        <Input id="site" placeholder="e.g., CMC, Gotera" />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="area">Area (m²)</Label>
        <div className="flex gap-2">
          <Input id="area-min" type="number" placeholder="Min" />
          <Input id="area-max" type="number" placeholder="Max" />
        </div>
      </div>

      <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">Apply Filters</Button>
      <Button variant="outline" className="w-full">Reset</Button>
    </div>
  );
}
