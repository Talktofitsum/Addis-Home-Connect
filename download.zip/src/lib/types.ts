export type User = {
  id: string;
  name: string;
  avatarUrl: string;
  role: 'owner' | 'broker' | 'renter' | 'admin';
};

export type Location = {
  town: string;
  subcity: string;
  site: string;
  gps: {
    lat: number;
    lng: number;
  };
};

export type Property = {
  id: string;
  title: string;
  description: {
    en: string;
    am?: string;
    or?: string;
  };
  location: Location;
  areaM2: number;
  bedrooms: number;
  bathrooms: number;
  blockNo: string;
  floorNo: number;
  houseNo: string;
  price: number;
  priceType: 'per month';
  photos: string[]; // Array of image placeholder IDs
  status: 'draft' | 'published' | 'pending_approval' | 'rented';
  postedAt: string;
  availableFrom: string;
  poster: User;
  commissionPercent?: number;
};
